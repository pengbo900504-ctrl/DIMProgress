#ifndef DIMProgressView_h
#define DIMProgressView_h

#import <UIKit/UIKit.h>

// 渐变粉色圆形进度条
@interface DIMCircularProgressView : UIView

@property (nonatomic, assign) CGFloat progress;           // 0.0 ~ 1.0
@property (nonatomic, strong) UIColor *progressColor;      // 进度条颜色
@property (nonatomic, strong) UIColor *trackColor;        // 背景轨道颜色
@property (nonatomic, assign) CGFloat lineWidth;          // 线宽

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;

@end

// 专辑封面容器（含进度条）
@interface DIMAlbumProgressView : UIView

@property (nonatomic, strong) UIImageView *albumImageView;  // 专辑封面
@property (nonatomic, strong) DIMCircularProgressView *progressView; // 进度条

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
- (void)setAlbumImage:(UIImage *)image;
- (instancetype)initWithSize:(CGFloat)size;

@end

#endif /* DIMProgressView_h */
