import UIKit
import MediaPlayer
import SpringBoard

// MARK: - 配置
struct DIMProgressConfig {
    static var progressColor: UIColor = UIColor(red: 1.0, green: 0.2, blue: 0.4, alpha: 1.0) // 渐变粉
    static var trackColor: UIColor = UIColor.white.withAlphaComponent(0.2)
    static var lineWidth: CGFloat = 4.0
    static var animationDuration: TimeInterval = 0.3
}

// MARK: - 圆形进度条视图
@objc class DIMCircularProgressView: UIView {
    
    @objc var progress: CGFloat = 0.0 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    @objc var progressColor: UIColor = DIMProgressConfig.progressColor
    @objc var trackColor: UIColor = DIMProgressConfig.trackColor
    @objc var lineWidth: CGFloat = DIMProgressConfig.lineWidth
    @objc var showGradient: Bool = true
    
    private var gradientLayer: CAGradientLayer?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private func setup() {
        backgroundColor = .clear
        isOpaque = false
    }
    
    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }
        
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2.0 - lineWidth / 2.0
        
        // 绘制背景轨道
        context.setStrokeColor(trackColor.cgColor)
        context.setLineWidth(lineWidth)
        context.setLineCap(.round)
        context.addArc(center: center, radius: radius, startAngle: 0, endAngle: .pi * 2, clockwise: true)
        context.strokePath()
        
        // 绘制进度
        let startAngle = -CGFloat.pi / 2
        let endAngle = startAngle + (progress * CGFloat.pi * 2)
        
        if showGradient {
            // 创建渐变
            let colors = [UIColor.systemPink.cgColor, UIColor(red: 1.0, green: 0.3, blue: 0.5, alpha: 1.0).cgColor]
            let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: [0.0, 1.0])!
            
            context.saveGState()
            
            // 创建扇形路径
            let path = UIBezierPath()
            path.move(to: center)
            path.addArc(withCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
            path.close()
            path.addLine(to: center)
            
            context.addPath(path.cgPath)
            context.clip()
            
            // 绘制渐变
            context.drawLinearGradient(
                gradient,
                start: CGPoint(x: center.x - radius, y: center.y - radius),
                end: CGPoint(x: center.x + radius, y: center.y + radius),
                options: []
            )
            
            context.restoreGState()
        } else {
            context.setStrokeColor(progressColor.cgColor)
            context.setLineWidth(lineWidth)
            context.setLineCap(.round)
            context.addArc(center: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: false)
            context.strokePath()
        }
    }
    
    @objc func setProgress(_ progress: CGFloat, animated: Bool) {
        let clampedProgress = max(0, min(1, progress))
        
        if animated {
            UIView.animate(withDuration: DIMProgressConfig.animationDuration, delay: 0, options: .curveEaseInOut) {
                self.progress = clampedProgress
            }
        } else {
            self.progress = clampedProgress
        }
    }
}

// MARK: - 专辑封面容器视图
@objc class DIMAlbumProgressView: UIView {
    
    @objc let albumImageView: UIImageView
    @objc let progressView: DIMCircularProgressView
    private let coverSize: CGFloat
    
    @objc var albumSize: CGFloat {
        return coverSize
    }
    
    @objc init(size: CGFloat) {
        self.coverSize = size
        
        // 专辑封面
        let artworkSize = size - DIMProgressConfig.lineWidth * 4
        albumImageView = UIImageView(frame: CGRect(
            x: DIMProgressConfig.lineWidth * 2,
            y: DIMProgressConfig.lineWidth * 2,
            width: artworkSize,
            height: artworkSize
        ))
        
        // 进度条
        progressView = DIMCircularProgressView(frame: CGRect(x: 0, y: 0, width: size, height: size))
        
        super.init(frame: CGRect(x: 0, y: 0, width: size, height: size))
        
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        backgroundColor = .clear
        
        // 专辑封面设置
        albumImageView.contentMode = .scaleAspectFill
        albumImageView.clipsToBounds = true
        albumImageView.layer.cornerRadius = 12
        albumImageView.backgroundColor = .systemGray5
        addSubview(albumImageView)
        
        // 进度条
        progressView.lineWidth = DIMProgressConfig.lineWidth
        addSubview(progressView)
    }
    
    @objc func setProgress(_ progress: CGFloat, animated: Bool) {
        progressView.setProgress(progress, animated: animated)
    }
    
    @objc func setAlbumImage(_ image: UIImage?) {
        albumImageView.image = image
    }
}

// MARK: - 音乐观察者
@objc class DIMMusicObserver: NSObject {
    
    private var progressTimer: Timer?
    @objc var currentProgress: CGFloat = 0.0
    @objc var currentPlaybackTime: TimeInterval = 0
    @objc var totalDuration: TimeInterval = 0
    
    @objc override init() {
        super.init()
    }
    
    deinit {
        stopObserving()
    }
    
    @objc func startObserving() {
        stopObserving()
        
        updateNowPlayingInfo()
        
        // 定时器更新进度
        progressTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.updateProgress()
        }
        
        // 监听远程控制事件
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleNowPlayingInfoChange),
            name: .MPMusicPlayerControllerNowPlayingItemDidChange,
            object: nil
        )
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleNowPlayingInfoChange),
            name: .MPNowPlayingInfoDidChange,
            object: nil
        )
    }
    
    @objc func stopObserving() {
        progressTimer?.invalidate()
        progressTimer = nil
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func updateNowPlayingInfo() {
        let infoCenter = MPNowPlayingInfoCenter.default()
        guard let info = infoCenter.nowPlayingInfo else { return }
        
        if let duration = info[MPMediaItemPropertyPlaybackDuration] as? TimeInterval {
            totalDuration = duration
        }
        
        if let currentTime = info[MPNowPlayingInfoPropertyElapsedPlaybackTime] as? TimeInterval {
            currentPlaybackTime = currentTime
        }
        
        updateProgress()
    }
    
    @objc private func handleNowPlayingInfoChange() {
        updateNowPlayingInfo()
    }
    
    @objc private func updateProgress() {
        if totalDuration > 0 {
            currentProgress = CGFloat(currentPlaybackTime / totalDuration)
        } else {
            currentProgress = 0
        }
    }
    
    @objc func getCurrentProgress() -> CGFloat {
        return currentProgress
    }
}

// MARK: - Dynamic Island 管理器
@objc class DIMDynamicIslandManager: NSObject {
    
    static let shared = DIMDynamicIslandManager()
    
    @objc var albumView: DIMAlbumProgressView?
    private let musicObserver = DIMMusicObserver()
    private var containerView: UIView?
    private var updateTimer: Timer?
    
    private override init() {
        super.init()
    }
    
    @objc func setupDynamicIslandView() {
        // 查找 Dynamic Island 窗口
        guard let diWindow = findDynamicIslandWindow() else {
            print("[DIMProgress] Dynamic Island window not found")
            return
        }
        
        // 创建容器视图
        let containerSize: CGFloat = 60
        containerView = UIView(frame: CGRect(x: 0, y: 0, width: containerSize, height: containerSize))
        containerView?.backgroundColor = .clear
        
        // 创建专辑封面+进度条视图
        albumView = DIMAlbumProgressView(size: containerSize)
        containerView?.addSubview(albumView!)
        
        // 添加到 Dynamic Island
        diWindow.addSubview(containerView!)
        
        // 设置约束（居中）
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        if let container = containerView {
            NSLayoutConstraint.activate([
                container.centerXAnchor.constraint(equalTo: diWindow.centerXAnchor),
                container.centerYAnchor.constraint(equalTo: diWindow.centerYAnchor),
                container.widthAnchor.constraint(equalToConstant: containerSize),
                container.heightAnchor.constraint(equalToConstant: containerSize)
            ])
        }
        
        // 开始监听音乐
        musicObserver.startObserving()
        
        // 启动进度更新定时器
        updateTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            let progress = self.musicObserver.getCurrentProgress()
            self.updateProgress(progress)
        }
        
        print("[DIMProgress] Dynamic Island Music Progress initialized")
    }
    
    @objc func updateProgress(_ progress: CGFloat) {
        DispatchQueue.main.async { [weak self] in
            self?.albumView?.setProgress(progress, animated: true)
        }
    }
    
    @objc func updateAlbumArtwork(_ image: UIImage?) {
        DispatchQueue.main.async { [weak self] in
            self?.albumView?.setAlbumImage(image)
        }
    }
    
    private func findDynamicIslandWindow() -> UIWindow? {
        for window in UIApplication.shared.windows {
            if String(describing: type(of: window)).contains("DynamicIsland") {
                return window
            }
        }
        return nil
    }
}

// MARK: - Hook SpringBoard
@objc class DIMSpringBoardHook: NSObject {
    
    @objc static func initialize() {
        print("[DIMProgress] Tweak Loaded")
        
        // 延迟初始化
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            DIMDynamicIslandManager.shared.setupDynamicIslandView()
        }
    }
}
