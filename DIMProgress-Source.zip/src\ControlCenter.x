#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <MediaPlayer/MediaPlayer.h>

// ==================== Control Center 音乐进度条 Hook ====================

// Hook Control Center 的 Now Playing 模块
%hook CCVeryLowBrightnessHangarViewController

- (void)viewDidLoad {
    %orig;
    
    // 添加自定义进度指示器
    LOG(@"Control Center loaded - Music Progress View Added");
}

%end

// Hook Now Playing 模块
%hook MPNowPlayingMaterializationHostingView

- (void)didMoveToWindow {
    %orig;
    
    // 在这里注入自定义进度条
    [self setupMusicProgressIndicator];
}

- (void)setupMusicProgressIndicator {
    // 获取当前视图的父容器
    UIView *parentView = self.superview;
    
    if (!parentView) return;
    
    // 检查是否已经添加过
    for (UIView *subview in parentView.subviews) {
        if ([NSStringFromClass([subview class]) containsString:@"DIMProgress"]) {
            return;
        }
    }
    
    // 创建进度条容器
    CGFloat progressSize = 44;
    UIView *progressContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, progressSize, progressSize)];
    progressContainer.tag = 999; // 标记为我们创建的视图
    
    // 添加圆形进度条
    UIView *progressRing = [[UIView alloc] initWithFrame:CGRectMake(4, 4, progressSize - 8, progressSize - 8)];
    progressRing.layer.cornerRadius = (progressSize - 8) / 2;
    progressRing.layer.borderWidth = 3;
    progressRing.layer.borderColor = [UIColor systemPinkColor].CGColor;
    [progressContainer addSubview:progressRing];
    
    // 添加专辑缩略图
    UIImageView *artworkView = [[UIImageView alloc] initWithFrame:CGRectMake(8, 8, progressSize - 16, progressSize - 16)];
    artworkView.contentMode = UIViewContentModeScaleAspectFill;
    artworkView.clipsToBounds = YES;
    artworkView.layer.cornerRadius = (progressSize - 16) / 2;
    artworkView.backgroundColor = [UIColor systemGrayColorColor];
    [progressContainer addSubview:artworkView];
    
    // 保存专辑视图引用
    objc_setAssociatedObject(self, "DIMArtworkView", artworkView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(self, "DIMProgressRing", progressRing, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    // 监听 Now Playing 变化
    [[NSNotificationCenter defaultCenter] addObserver:self 
        selector:@selector(updateMusicProgress:) 
        name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification 
        object:nil];
    
    // 监听专辑封面变化
    [[NSNotificationCenter defaultCenter] addObserver:self 
        selector:@selector(updateArtwork:) 
        name:MPNowPlayingInfoCenterDidChangeNotification 
        object:nil];
    
    LOG(@"Music progress indicator setup complete");
}

- (void)updateMusicProgress:(NSNotification *)notification {
    // 获取当前播放进度
    MPNowPlayingInfoCenter *infoCenter = [MPNowPlayingInfoCenter defaultCenter];
    NSDictionary *info = infoCenter.nowPlayingInfo;
    
    if (!info) return;
    
    NSNumber *duration = info[MPMediaItemPropertyPlaybackDuration];
    NSNumber *currentTime = info[MPNowPlayingInfoPropertyElapsedPlaybackTime];
    
    if (duration && currentTime) {
        CGFloat progress = [currentTime doubleValue] / [duration doubleValue];
        
        UIView *progressRing = objc_getAssociatedObject(self, "DIMProgressRing");
        if (progressRing) {
            [self animateProgressRing:progressRing toProgress:progress];
        }
    }
}

- (void)updateArtwork:(NSNotification *)notification {
    MPNowPlayingInfoCenter *infoCenter = [MPNowPlayingInfoCenter defaultCenter];
    NSDictionary *info = infoCenter.nowPlayingInfo;
    
    UIImageView *artworkView = objc_getAssociatedObject(self, "DIMArtworkView");
    
    if (info && artworkView) {
        MPMediaItemArtwork *artwork = info[MPMediaItemPropertyArtwork];
        if (artwork && [artwork respondsToSelector:@selector(image)]) {
            UIImage *image = [artwork imageWithSize:artworkView.bounds.size];
            dispatch_async(dispatch_get_main_queue(), ^{
                artworkView.image = image;
            });
        }
    }
}

- (void)animateProgressRing:(UIView *)ring toProgress:(CGFloat)progress {
    // 创建进度条动画
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    
    CGFloat size = ring.bounds.size.width;
    CGPoint center = CGPointMake(size / 2, size / 2);
    CGFloat radius = (size - 6) / 2;
    
    // 创建圆形路径
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithArcCenter:center
        radius:radius
        startAngle:-M_PI_2
        endAngle:M_PI_2 * 3
        clockwise:YES];
    
    maskLayer.path = [circlePath CGPath];
    maskLayer.strokeColor = [UIColor systemPinkColor].CGColor;
    maskLayer.fillColor = [UIColor clearColor].CGColor;
    maskLayer.lineWidth = 3;
    maskLayer.strokeStart = 0;
    maskLayer.strokeEnd = progress;
    
    ring.layer.mask = maskLayer;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    %orig;
}

%end

// Hook 锁屏界面的 Now Playing
%hook SBLockScreenViewController

- (void)viewDidLoad {
    %orig;
    
    // 在锁屏添加进度条
    LOG(@"Lock Screen loaded");
}

%end
