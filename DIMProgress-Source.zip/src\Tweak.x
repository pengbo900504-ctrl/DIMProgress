#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

// 日志宏
#define LOG(fmt, ...) NSLog(@"[DIMProgress] " fmt, ##__VA_ARGS__)

// ==================== 配置 ====================
#define PROGRESS_COLOR [UIColor colorWithRed:1.0 green:0.2 blue:0.4 alpha:1.0] // 渐变粉
#define PROGRESS_BG_COLOR [UIColor colorWithWhite:1.0 alpha:0.2]
#define PROGRESS_LINE_WIDTH 4.0
#define ANIMATION_DURATION 0.3

// ==================== 进度条视图 ====================
@interface DIMCircularProgressView : UIView

@property (nonatomic, assign) CGFloat progress; // 0.0 - 1.0
@property (nonatomic, strong) UIColor *progressColor;
@property (nonatomic, strong) UIColor *trackColor;
@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, assign) BOOL showGradient; // 是否显示渐变

@end

@implementation DIMCircularProgressView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.progress = 0.0;
        self.progressColor = PROGRESS_COLOR;
        self.trackColor = PROGRESS_BG_COLOR;
        self.lineWidth = PROGRESS_LINE_WIDTH;
        self.showGradient = YES;
        self.opaque = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGPoint center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
    CGFloat radius = MIN(rect.size.width, rect.size.height) / 2.0 - self.lineWidth / 2.0;
    
    // 绘制背景轨道
    CGContextSetStrokeColorWithColor(context, self.trackColor.CGColor);
    CGContextSetLineWidth(context, self.lineWidth);
    CGContextSetLineCap(context, kCGLineCapRound);
    CGContextAddArc(context, center.x, center.y, radius, 0, M_PI * 2, 0);
    CGContextStrokePath(context);
    
    // 绘制进度
    CGFloat startAngle = -M_PI_2; // 从顶部开始
    CGFloat endAngle = startAngle + (self.progress * M_PI * 2);
    
    if (self.showGradient) {
        // 创建渐变
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGFloat locations[] = {0.0, 1.0};
        
        // 获取当前进度对应的渐变颜色
        UIColor *startColor = [self interpolatedColorFrom:PROGRESS_COLOR to:[UIColor systemPinkColor] progress:self.progress];
        UIColor *endColor = PROGRESS_COLOR;
        
        NSArray *colors = @[
            (id)startColor.CGColor,
            (id)endColor.CGColor
        ];
        
        CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
        
        // 创建路径
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path addArcWithCenter:center radius:radius startAngle:startAngle endAngle:endAngle clockwise:YES];
        
        // 使用渐变描边
        CGContextSaveGState(context);
        [path addLineToPoint:center];
        [path addLineToPoint:CGPointMake(center.x + radius * cos(startAngle), center.y + radius * sin(startAngle))];
        [path closePath];
        CGContextAddPath(context, path.CGPath);
        CGContextClip(context);
        
        CGContextDrawLinearGradient(context, gradient,
            CGPointMake(center.x - radius, center.y - radius),
            CGPointMake(center.x + radius, center.y + radius), 0);
        
        CGContextRestoreGState(context);
        CGGradientRelease(gradient);
        CGColorSpaceRelease(colorSpace);
    } else {
        CGContextSetStrokeColorWithColor(context, self.progressColor.CGColor);
        CGContextSetLineWidth(context, self.lineWidth);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextAddArc(context, center.x, center.y, radius, startAngle, endAngle, 0);
        CGContextStrokePath(context);
    }
}

- (UIColor *)interpolatedColorFrom:(UIColor *)fromColor to:(UIColor *)toColor progress:(CGFloat)progress {
    CGFloat fromRed, fromGreen, fromBlue, fromAlpha;
    CGFloat toRed, toGreen, toBlue, toAlpha;
    
    [fromColor getRed:&fromRed green:&fromGreen blue:&fromBlue alpha:&fromAlpha];
    [toColor getRed:&toRed green:&toGreen blue:&toBlue alpha:&toAlpha];
    
    CGFloat red = fromRed + (toRed - fromRed) * progress;
    CGFloat green = fromGreen + (toGreen - fromGreen) * progress;
    CGFloat blue = fromBlue + (toBlue - fromBlue) * progress;
    CGFloat alpha = fromAlpha + (toAlpha - fromAlpha) * progress;
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
}

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated {
    if (animated) {
        [UIView animateWithDuration:ANIMATION_DURATION delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            self->_progress = MIN(MAX(progress, 0.0), 1.0);
            [self setNeedsDisplay];
        } completion:nil];
    } else {
        _progress = MIN(MAX(progress, 0.0), 1.0);
        [self setNeedsDisplay];
    }
}

@end

// ==================== 专辑封面容器视图 ====================
@interface DIMAlbumArtworkView : UIView

@property (nonatomic, strong) UIImageView *albumImageView;
@property (nonatomic, strong) DIMCircularProgressView *progressView;
@property (nonatomic, assign) CGFloat coverSize;

@end

@implementation DIMAlbumArtworkView

- (instancetype)initWithSize:(CGFloat)size {
    self = [super initWithFrame:CGRectMake(0, 0, size, size)];
    if (self) {
        _coverSize = size;
        [self setupViews];
    }
    return self;
}

- (void)setupViews {
    self.backgroundColor = [UIColor clearColor];
    
    // 创建专辑封面
    CGFloat artworkSize = self.coverSize - PROGRESS_LINE_WIDTH * 4;
    self.albumImageView = [[UIImageView alloc] initWithFrame:CGRectMake(PROGRESS_LINE_WIDTH * 2, PROGRESS_LINE_WIDTH * 2, artworkSize, artworkSize)];
    self.albumImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.albumImageView.clipsToBounds = YES;
    self.albumImageView.layer.cornerRadius = 12;
    self.albumImageView.backgroundColor = [UIColor systemGray5Color];
    [self addSubview:self.albumImageView];
    
    // 创建进度条视图（在外层）
    self.progressView = [[DIMCircularProgressView alloc] initWithFrame:self.bounds];
    self.progressView.lineWidth = PROGRESS_LINE_WIDTH;
    [self addSubview:self.progressView];
}

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated {
    [self.progressView setProgress:progress animated:animated];
}

- (void)setAlbumImage:(UIImage *)image {
    self.albumImageView.image = image;
}

@end

// ==================== 音乐数据监听器 ====================
@interface DIMMusicObserver : NSObject

@property (nonatomic, strong) NSTimer *progressTimer;
@property (nonatomic, assign) CGFloat currentProgress;
@property (nonatomic, assign) NSTimeInterval currentPlaybackTime;
@property (nonatomic, assign) NSTimeInterval totalDuration;

- (void)startObserving;
- (void)stopObserving;
- (CGFloat)getCurrentProgress;

@end

@implementation DIMMusicObserver

- (instancetype)init {
    self = [super init];
    if (self) {
        _currentProgress = 0.0;
        _currentPlaybackTime = 0;
        _totalDuration = 0;
    }
    return self;
}

- (void)dealloc {
    [self stopObserving];
}

- (void)startObserving {
    [self stopObserving];
    
    // 使用MPNowPlayingInfoCenter获取当前播放信息
    [self updateNowPlayingInfo];
    
    // 定时器更新进度
    self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *timer) {
        [self updateProgress];
    }];
    
    // 监听远程控制事件
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNowPlayingInfoChange:) 
        name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNowPlayingInfoChange:) 
        name:MPNowPlayingInfoCenterDidChangeNotification object:nil];
}

- (void)stopObserving {
    [self.progressTimer invalidate];
    self.progressTimer = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)updateNowPlayingInfo {
    MPNowPlayingInfoCenter *infoCenter = [MPNowPlayingInfoCenter defaultCenter];
    NSDictionary *info = infoCenter.nowPlayingInfo;
    
    if (info) {
        NSNumber *duration = info[MPMediaItemPropertyPlaybackDuration];
        NSNumber *currentTime = info[MPNowPlayingInfoPropertyElapsedPlaybackTime];
        
        if (duration) {
            self.totalDuration = [duration doubleValue];
        }
        if (currentTime) {
            self.currentPlaybackTime = [currentTime doubleValue];
        }
        
        [self updateProgress];
    }
}

- (void)handleNowPlayingInfoChange:(NSNotification *)notification {
    [self updateNowPlayingInfo];
}

- (void)updateProgress {
    [self updateNowPlayingInfo];
    
    if (self.totalDuration > 0) {
        self.currentProgress = self.currentPlaybackTime / self.totalDuration;
    } else {
        self.currentProgress = 0;
    }
}

- (CGFloat)getCurrentProgress {
    return _currentProgress;
}

@end

// ==================== Dynamic Island 集成 ====================
@interface DIMDynamicIslandManager : NSObject

@property (nonatomic, strong) DIMAlbumArtworkView *albumView;
@property (nonatomic, strong) DIMMusicObserver *musicObserver;
@property (nonatomic, strong) UIView *containerView;

+ (instancetype)sharedInstance;
- (void)setupDynamicIslandView;
- (void)updateProgress:(CGFloat)progress;
- (void)updateAlbumArtwork:(UIImage *)image;

@end

@implementation DIMDynamicIslandManager

+ (instancetype)sharedInstance {
    static DIMDynamicIslandManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[DIMDynamicIslandManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _musicObserver = [[DIMMusicObserver alloc] init];
    }
    return self;
}

- (void)setupDynamicIslandView {
    // 获取Dynamic Island的window
    UIWindow *dynamicIslandWindow = nil;
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if ([NSStringFromClass([window class]) containsString:@"DynamicIsland"]) {
            dynamicIslandWindow = window;
            break;
        }
    }
    
    if (!dynamicIslandWindow) {
        LOG(@"Dynamic Island window not found");
        return;
    }
    
    // 创建容器视图
    CGFloat containerSize = 60;
    self.containerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, containerSize, containerSize)];
    self.containerView.backgroundColor = [UIColor clearColor];
    
    // 创建专辑封面+进度条视图
    self.albumView = [[DIMAlbumArtworkView alloc] initWithSize:containerSize];
    [self.containerView addSubview:self.albumView];
    
    // 添加到Dynamic Island
    [dynamicIslandWindow addSubview:self.containerView];
    
    // 设置约束（居中显示）
    self.containerView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.containerView.centerXAnchor constraintEqualToAnchor:dynamicIslandWindow.centerXAnchor],
        [self.containerView.centerYAnchor constraintEqualToAnchor:dynamicIslandWindow.centerYAnchor],
        [self.containerView.widthAnchor constraintEqualToConstant:containerSize],
        [self.containerView.heightAnchor constraintEqualToConstant:containerSize]
    ]];
    
    // 开始监听音乐
    [self.musicObserver startObserving];
    
    // 启动进度更新定时器
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer *timer) {
        CGFloat progress = [self.musicObserver getCurrentProgress];
        [self updateProgress:progress];
    }];
}

- (void)updateProgress:(CGFloat)progress {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.albumView setProgress:progress animated:YES];
    });
}

- (void)updateAlbumArtwork:(UIImage *)image {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.albumView setAlbumImage:image];
    });
}

@end

// ==================== Hook SpringBoard ====================
%hook SpringBoard

- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    
    // 延迟初始化，等待Dynamic Island准备好
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[DIMDynamicIslandManager sharedInstance] setupDynamicIslandView];
        LOG(@"Dynamic Island Music Progress initialized");
    });
}

%end

// ==================== Hook 音乐播放时显示Dynamic Island内容 ====================
%hook SBNowPlayingBarView // iOS 15及之前

- (void)setNowPlayingArtwork:(id)artwork {
    %orig;
    
    UIImage *image = nil;
    if ([artwork isKindOfClass:[UIImage class]]) {
        image = (UIImage *)artwork;
    } else if ([artwork respondsToSelector:@selector(image)]) {
        image = [artwork performSelector:@selector(image)];
    }
    
    if (image) {
        [[DIMDynamicIslandManager sharedInstance] updateAlbumArtwork:image];
    }
}

%end

%hook MPNowPlayingViewController // iOS 16+

- (void)viewDidLoad {
    %orig;
    
    // 监听专辑封面变化
    [self observeValueForKeyPath:@"nowPlayingItem" ofUnit:@"" change:nil context:nil];
}

%end

// ==================== 初始化入口 ====================
__attribute__((constructor))
static void initialize() {
    LOG(@"Dynamic Island Music Progress Tweak Loaded");
}
