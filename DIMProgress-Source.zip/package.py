#!/usr/bin/env python3
"""
打包 iOS 越狱插件为 .deb 文件
Windows 下直接运行，无需 Linux/Mac
"""

import os
import sys
import tarfile
import io
import hashlib
import datetime
import subprocess

def create_deb():
    # 项目路径
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 包信息
    package_name = "com.dim.progress"
    version = "1.0.0"
    architecture = "iphoneos-arm"
    maintainer = "DIM Developer"
    description = "Dynamic Island Music Progress - 灵动岛音乐进度条"
    author = "DIM Developer"
    section = "Tweaks"
    homepage = "https://github.com/dim-progress"
    
    # 输出路径
    output_file = os.path.join(base_dir, f"{package_name}_{version}_iphoneos-arm.deb")
    
    # 创建临时目录
    work_dir = os.path.join(base_dir, "_pkg_temp")
    data_dir = os.path.join(work_dir, "data")
    control_dir = os.path.join(work_dir, "control")
    
    # 清理旧文件
    for d in [work_dir, data_dir, control_dir]:
        if os.path.exists(d):
            import shutil
            shutil.rmtree(d)
    
    os.makedirs(data_dir)
    os.makedirs(control_dir)
    
    # 复制文件到 data 目录
    # 安装路径: /Library/MobileSubstrate/DynamicLibraries/
    target_dir = os.path.join(data_dir, "Library/MobileSubstrate/DynamicLibraries")
    os.makedirs(target_dir)
    
    # 复制 .plist 文件
    plist_src = os.path.join(base_dir, "DynamicIslandMusicProgress.plist")
    if os.path.exists(plist_src):
        import shutil
        shutil.copy(plist_src, target_dir)
    
    # 创建 dylib 占位符（实际编译时会生成）
    dylib_path = os.path.join(target_dir, f"{package_name}.dylib")
    
    # 创建 control 文件
    control_content = f"""Package: {package_name}
Version: {version}
Architecture: {architecture}
Maintainer: {maintainer}
Author: {author}
Section: {section}
Description: {description}
Homepage: {homepage}
"""
    
    control_file = os.path.join(control_dir, "control")
    with open(control_file, 'w', encoding='utf-8') as f:
        f.write(control_content)
    
    # 创建 preinst 脚本（安装前执行）
    preinst_content = """#!/bin/bash
# Pre-install script
if [ -f /Library/MobileSubstrate/DynamicLibraries/com.dim.progress.dylib ]; then
    killall -9 SpringBoard 2>/dev/null || true
fi
"""
    preinst_file = os.path.join(control_dir, "preinst")
    with open(preinst_file, 'w', encoding='utf-8') as f:
        f.write(preinst_content)
    os.chmod(preinst_file, 0o755)
    
    # 创建 postinst 脚本（安装后执行）
    postinst_content = """#!/bin/bash
# Post-install script
# 重新加载 SpringBoard
killall -9 SpringBoard 2>/dev/null || true
"""
    postinst_file = os.path.join(control_dir, "postinst")
    with open(postinst_file, 'w', encoding='utf-8') as f:
        f.write(postinst_content)
    os.chmod(postinst_file, 0o755)
    
    # 创建 prerm 脚本（卸载前执行）
    prerm_content = """#!/bin/bash
# Pre-removal script
killall -9 SpringBoard 2>/dev/null || true
"""
    prerm_file = os.path.join(control_dir, "prerm")
    with open(prerm_file, 'w', encoding='utf-8') as f:
        f.write(prerm_content)
    os.chmod(prerm_file, 0o755)
    
    # 创建 postrm 脚本（卸载后执行）
    postrm_content = """#!/bin/bash
# Post-removal script
killall -9 SpringBoard 2>/dev/null || true
"""
    postrm_file = os.path.join(control_dir, "postrm")
    with open(postrm_file, 'w', encoding='utf-8') as f:
        f.write(postrm_content)
    os.chmod(postrm_file, 0o755)
    
    # 创建 md5sums 文件
    md5sums_content = ""
    for root, dirs, files in os.walk(data_dir):
        for file in files:
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(file_path, data_dir)
            with open(file_path, 'rb') as f:
                md5 = hashlib.md5(f.read()).hexdigest()
            md5sums_content += f"{md5}  ./{rel_path}\n"
    
    md5sums_file = os.path.join(control_dir, "md5sums")
    with open(md5sums_file, 'w', encoding='utf-8') as f:
        f.write(md5sums_content)
    
    # 创建 debian-binary
    debian_binary_file = os.path.join(work_dir, "debian-binary")
    with open(debian_binary_file, 'w') as f:
        f.write("2.0\n")
    
    # 创建 data.tar.gz
    data_tar_path = os.path.join(work_dir, "data.tar.gz")
    with tarfile.open(data_tar_path, "w:gz") as tar:
        tar.add(data_dir, arcname=".")
    
    # 创建 control.tar.gz
    control_tar_path = os.path.join(work_dir, "control.tar.gz")
    with tarfile.open(control_tar_path, "w:gz") as tar:
        tar.add(control_dir, arcname=".")
    
    # 使用 ar 创建 deb 文件
    # deb 格式: ar archive "deb " version info
    if os.path.exists(output_file):
        os.remove(output_file)
    
    # 手动创建 ar 格式
    create_ar_deb(output_file, debian_binary_file, control_tar_path, data_tar_path)
    
    # 清理临时文件
    import shutil
    shutil.rmtree(work_dir)
    
    print(f"✅ 打包完成: {output_file}")
    print(f"📦 包大小: {os.path.getsize(output_file) / 1024:.2f} KB")
    
    return output_file

def create_ar_deb(output_file, debian_binary, control_tar, data_tar):
    """创建 ar 格式的 deb 文件"""
    
    with open(output_file, 'wb') as ar_file:
        # AR magic header
        ar_file.write(b"!<arch>\n")
        
        # debian-binary
        add_ar_member(ar_file, "debian-binary", debian_binary)
        
        # control.tar.gz
        add_ar_member(ar_file, "control.tar.gz", control_tar)
        
        # data.tar.gz
        add_ar_member(ar_file, "data.tar.gz", data_tar)

def add_ar_member(ar_file, name, file_path):
    """添加 ar 成员"""
    with open(file_path, 'rb') as f:
        data = f.read()
    
    # AR 成员头: name.pad(16) timestamp(12) owner(6) group(6) mode(8) size(10) magic(2)
    name_padded = name.encode().ljust(16)
    header = name_padded
    header += b"0" * 12  # timestamp
    header += b"0" * 6   # owner
    header += b"0" * 6   # group
    header += b"100644"  # mode (rw-r--r--)
    header += f"{len(data):10d}".encode()
    header += b"`\n"
    
    ar_file.write(header)
    ar_file.write(data)
    
    # 对齐到 2 字节
    if len(data) % 2 != 0:
        ar_file.write(b"\n")

if __name__ == "__main__":
    try:
        output = create_deb()
        
        # 复制到用户桌面
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        desktop_file = os.path.join(desktop, os.path.basename(output))
        import shutil
        shutil.copy(output, desktop_file)
        print(f"📁 已复制到桌面: {desktop_file}")
        
    except Exception as e:
        print(f"❌ 打包失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
