# iOS 越狱插件 Deb 打包脚本
# Windows PowerShell 版本，无需 Python 或外部依赖

$ErrorActionPreference = "Stop"

# 项目配置
$PackageName = "com.dim.progress"
$Version = "1.0.0"
$Architecture = "iphoneos-arm"
$Maintainer = "DIM Developer"
$Description = "Dynamic Island Music Progress"
$Section = "Tweaks"

# 路径配置
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TempDir = Join-Path $ProjectDir "_deb_temp"
$OutputDir = Join-Path $ProjectDir "packages"
$OutputFile = Join-Path $ProjectDir "${PackageName}_${Version}_iphoneos-arm.deb"
$Desktop = [Environment]::GetFolderPath("Desktop")
$DesktopFile = Join-Path $Desktop "${PackageName}_${Version}_iphoneos-arm.deb"

Write-Host "📦 开始打包插件..." -ForegroundColor Cyan

# 清理旧文件
if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force }
if (Test-Path $OutputFile) { Remove-Item $OutputFile -Force }

# 创建目录结构
$ControlDir = Join-Path $TempDir "control"
$DataDir = Join-Path $TempDir "data\Library\MobileSubstrate\DynamicLibraries"
New-Item -ItemType Directory -Path $ControlDir -Force | Out-Null
New-Item -ItemType Directory -Path $DataDir -Force | Out-Null

Write-Host "📁 创建目录结构..." -ForegroundColor Yellow

# 复制插件文件
$PlistSrc = Join-Path $ProjectDir "DynamicIslandMusicProgress.plist"
if (Test-Path $PlistSrc) {
    Copy-Item $PlistSrc $DataDir -Force
    Write-Host "  ✅ 复制 plist 文件" -ForegroundColor Green
}

# 复制 Tweak 源文件
$SrcDir = Join-Path $ProjectDir "src"
$DestSrcDir = Join-Path $DataDir "src"
New-Item -ItemType Directory -Path $DestSrcDir -Force | Out-Null

if (Test-Path $SrcDir) {
    Copy-Item "$SrcDir\*" $DestSrcDir -Recurse -Force
    Write-Host "  ✅ 复制源代码" -ForegroundColor Green
}

# 复制 Makefile
$MakefileSrc = Join-Path $ProjectDir "Makefile"
if (Test-Path $MakefileSrc) {
    Copy-Item $MakefileSrc $DataDir -Force
}

# 创建 control 文件
$ControlContent = @"
Package: $PackageName
Version: $Version
Architecture: $Architecture
Maintainer: $Maintainer
Section: $Section
Description: $Description
Author: $Maintainer
Homepage: https://github.com/dim-progress
"@

$ControlFile = Join-Path $ControlDir "control"
$ControlContent | Out-File -FilePath $ControlFile -Encoding UTF8

# 创建安装脚本
$PreinstContent = @"
#!/bin/bash
if [ -f /Library/MobileSubstrate/DynamicLibraries/${PackageName}.dylib ]; then
    killall -9 SpringBoard 2>/dev/null || true
fi
"@

$PostinstContent = @"
#!/bin/bash
# Post-install: Reload SpringBoard
killall -9 SpringBoard 2>/dev/null || true
"@

$PrermContent = @"
#!/bin/bash
killall -9 SpringBoard 2>/dev/null || true
"@

$PostrmContent = @"
#!/bin/bash
killall -9 SpringBoard 2>/dev/null || true
"@

$PreinstFile = Join-Path $ControlDir "preinst"
$PostinstFile = Join-Path $ControlDir "postinst"
$PrermFile = Join-Path $ControlDir "prerm"
$PostrmFile = Join-Path $ControlDir "postrm"

$PreinstContent | Out-File -FilePath $PreinstFile -Encoding UTF8
$PostinstContent | Out-File -FilePath $PostinstFile -Encoding UTF8
$PrermContent | Out-File -FilePath $PrermFile -Encoding UTF8
$PostrmContent | Out-File -FilePath $PostrmFile -Encoding UTF8

Write-Host "  ✅ 创建安装脚本" -ForegroundColor Green

# 创建 md5sums
$Md5sumsContent = ""
Get-ChildItem -Path "$TempDir\data" -Recurse -File | ForEach-Object {
    $RelPath = $_.FullName.Replace("$TempDir\data\", "").Replace("\", "/")
    $Md5 = (Get-FileHash $_.FullName -Algorithm MD5).Hash.ToLower()
    $Md5sumsContent += "$Md5  ./$RelPath`n"
}

$Md5sumsFile = Join-Path $ControlDir "md5sums"
$Md5sumsContent | Out-File -FilePath $Md5sumsFile -Encoding UTF8

Write-Host "  ✅ 创建 md5sums" -ForegroundColor Green

# 创建 debian-binary
$DebianBinaryFile = Join-Path $TempDir "debian-binary"
"2.0" | Out-File -FilePath $DebianBinaryFile -Encoding ASCII

Write-Host "📦 创建 tar.gz 归档..." -ForegroundColor Yellow

# 创建 data.tar.gz
$DataTarGz = Join-Path $TempDir "data.tar.gz"
$DataTarTemp = Join-Path $TempDir "data_temp.tar"
if (Test-Path $DataTarGz) { Remove-Item $DataTarGz -Force }
if (Test-Path $DataTarTemp) { Remove-Item $DataTarTemp -Force }

# 使用 .NET 压缩
Add-Type -AssemblyName System.IO.Compression.FileSystem

$DataFolder = Join-Path $TempDir "data"
$ZipTempPath = Join-Path $TempDir "data.zip"

# 手动创建 tar.gz
$TarDataPath = Join-Path $TempDir "data.tar"
if (Test-Path $TarDataPath) { Remove-Item $TarDataPath -Force }

# 简单 tar 格式实现
$TarData = New-Object System.Collections.ArrayList

function Add-TarEntry {
    param($name, $data)
    
    $nameBytes = [System.Text.Encoding]::ASCII.GetBytes($name.PadRight(100).Substring(0, 100))
    $sizeBytes = [System.BitConverter]::GetBytes([uint64]$data.Length)
    [Array]::Reverse($sizeBytes)
    $sizeStr = [System.Text.Encoding]::ASCII.GetString($sizeBytes).TrimEnd([char]0)
    $sizeBytes = [System.Text.Encoding]::ASCII.GetBytes($sizeStr.PadLeft(12).Substring(0, 12))
    
    $header = New-Object byte[] 512
    [Array]::Copy($nameBytes, 0, $header, 0, 100)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("00000000000".PadLeft(12)), 0, $header, 100, 12)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)), 0, $header, 108, 6)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)), 0, $header, 114, 6)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)), 0, $header, 124, 8)
    [Array]::Copy($sizeBytes, 0, $header, 124, 12)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("        0"), 0, $header, 136, 8)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("ustar "), 0, $header, 257, 8)
    
    [void]$TarData.AddRange($header)
    
    $paddedSize = (($data.Length + 511) / 512) * 512
    $paddedData = New-Object byte[] $paddedSize
    [Array]::Copy($data, 0, $paddedData, 0, $data.Length)
    [void]$TarData.AddRange($paddedData)
}

# 添加文件到 tar
Get-ChildItem -Path $DataFolder -Recurse -File | ForEach-Object {
    $RelPath = $_.FullName.Replace("$DataFolder\", "").Replace("\", "/")
    $Content = [System.IO.File]::ReadAllBytes($_.FullName)
    Add-TarEntry "./$RelPath" $Content
}

# tar 结束标记
[void]$TarData.AddRange((New-Object byte[] 1024))

# 压缩为 gzip
$TarDataBytes = $TarData.ToArray()
$MemStream = New-Object System.IO.MemoryStream
$GZipStream = New-Object System.IO.Compression.GZipStream($MemStream, [System.IO.Compression.CompressionMode]::Compress)
$GZipStream.Write($TarDataBytes, 0, $TarDataBytes.Length)
$GZipStream.Close()
[System.IO.File]::WriteAllBytes($DataTarGz, $MemStream.ToArray())

Write-Host "  ✅ 创建 data.tar.gz" -ForegroundColor Green

# 创建 control.tar.gz
$ControlTarGz = Join-Path $TempDir "control.tar.gz"
$ControlTarData = New-Object System.Collections.ArrayList

function Add-ControlEntry {
    param($name, $data)
    
    $nameBytes = [System.Text.Encoding]::ASCII.GetBytes($name.PadRight(100).Substring(0, 100))
    $sizeBytes = [System.Text.Encoding]::ASCII.GetBytes([string]([int]$data.Length).ToString().PadLeft(12))
    
    $header = New-Object byte[] 512
    [Array]::Copy($nameBytes, 0, $header, 0, 100)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("00000000000".PadLeft(12)), 0, $header, 100, 12)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)), 0, $header, 108, 6)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)), 0, $header, 114, 6)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)), 0, $header, 124, 8)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes([string]([int]$data.Length).ToString().PadLeft(12)), 0, $header, 124, 12)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("        0"), 0, $header, 136, 8)
    [Array]::Copy([System.Text.Encoding]::ASCII.GetBytes("ustar "), 0, $header, 257, 8)
    
    [void]$ControlTarData.AddRange($header)
    
    $paddedSize = (($data.Length + 511) / 512) * 512
    $paddedData = New-Object byte[] $paddedSize
    [Array]::Copy($data, 0, $paddedData, 0, $data.Length)
    [void]$ControlTarData.AddRange($paddedData)
}

# 添加 control 目录下的文件
Get-ChildItem -Path $ControlDir -File | ForEach-Object {
    $Content = [System.IO.File]::ReadAllBytes($_.FullName)
    Add-ControlEntry $_.Name $Content
}

# control.tar 结束标记
[void]$ControlTarData.AddRange((New-Object byte[] 1024))

# 压缩
$ControlTarBytes = $ControlTarData.ToArray()
$ControlMemStream = New-Object System.IO.MemoryStream
$ControlGZipStream = New-Object System.IO.Compression.GZipStream($ControlMemStream, [System.IO.Compression.CompressionMode]::Compress)
$ControlGZipStream.Write($ControlTarBytes, 0, $ControlTarBytes.Length)
$ControlGZipStream.Close()
[System.IO.File]::WriteAllBytes($ControlTarGz, $ControlMemStream.ToArray())

Write-Host "  ✅ 创建 control.tar.gz" -ForegroundColor Green

# 创建 deb 文件 (ar 格式)
Write-Host "📦 创建 .deb 文件..." -ForegroundColor Yellow

$DebianBinaryBytes = [System.IO.File]::ReadAllBytes($DebianBinaryFile)
$DataTarGzBytes = [System.IO.File]::ReadAllBytes($DataTarGz)
$ControlTarGzBytes = [System.IO.File]::ReadAllBytes($ControlTarGz)

$DebStream = New-Object System.IO.MemoryStream
$Writer = New-Object System.IO.BinaryWriter($DebStream)

# AR magic
$Writer.Write([System.Text.Encoding]::ASCII.GetBytes("!<arch>"))
$Writer.Write([byte]10)  # 换行

# 添加 ar 成员
function Write-ArMember {
    param($name, $data, $writer)
    
    # 格式化名称 (16 字节, 空格填充)
    $nameBytes = [System.Text.Encoding]::ASCII.GetBytes($name.PadRight(16))
    $Writer.Write($nameBytes)
    
    # 时间戳 (12 字节)
    $Writer.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(12)))
    
    # Owner (6 字节)
    $Writer.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
    
    # Group (6 字节)
    $Writer.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
    
    # Mode (8 字节)
    $Writer.Write([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)))
    
    # Size (10 字节)
    $Writer.Write([System.Text.Encoding]::ASCII.GetBytes($data.Length.ToString().PadLeft(10)))
    
    # Magic (2 字节)
    $Writer.Write([byte]96)  # `
    $Writer.Write([byte]10)   # 换行
    
    # 数据
    $Writer.Write($data)
    
    # 对齐到 2 字节
    if ($data.Length % 2 -ne 0) {
        $Writer.Write([byte]10)
    }
}

Write-ArMember "debian-binary         " $DebianBinaryBytes $Writer
Write-ArMember "control.tar.gz       " $ControlTarGzBytes $Writer
Write-ArMember "data.tar.gz          " $DataTarGzBytes $Writer

$Writer.Close()
[System.IO.File]::WriteAllBytes($OutputFile, $DebStream.ToArray())

Write-Host "  ✅ 创建 deb 文件" -ForegroundColor Green

# 复制到桌面
Write-Host "📁 复制到桌面..." -ForegroundColor Yellow
Copy-Item $OutputFile $DesktopFile -Force
Write-Host "  ✅ 已复制到桌面" -ForegroundColor Green

# 清理临时文件
Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue

# 完成
$FileSize = (Get-Item $DesktopFile).Length / 1KB
Write-Host ""
Write-Host "🎉 打包完成!" -ForegroundColor Green
Write-Host "📦 文件: $DesktopFile" -ForegroundColor Cyan
Write-Host "📊 大小: $($FileSize.ToString('F2')) KB" -ForegroundColor Cyan
Write-Host ""
Write-Host "⚠️  注意: 此 deb 包需要在 Mac/Linux 上重新编译才能在越狱设备上使用" -ForegroundColor Yellow
Write-Host "   Windows 打包仅包含源代码，实际使用需要用 Theos 编译" -ForegroundColor Yellow
