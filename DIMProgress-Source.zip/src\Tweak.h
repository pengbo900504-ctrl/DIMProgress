#ifndef Tweak_h
#define Tweak_h

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <objc/runtime.h>

#define LOG(fmt, ...) NSLog(@"[DIMProgress] " fmt, ##__VA_ARGS__)

// ==================== 配置 ====================
#define PROGRESS_COLOR [UIColor colorWithRed:1.0 green:0.2 blue:0.4 alpha:1.0]
#define TRACK_COLOR [UIColor colorWithWhite:1.0 alpha:0.2]
#define LINE_WIDTH 4.0
#define ANIMATION_DURATION 0.3

// ==================== 进度条视图 ====================
@interface DIMCircularProgressView : UIView
@property (nonatomic, assign) CGFloat progress;
@property (nonatomic, strong) UIColor *progressColor;
@property (nonatomic, strong) UIColor *trackColor;
@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, assign) BOOL showGradient;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
@end

// ==================== 专辑封面容器 ====================
@interface DIMAlbumProgressView : UIView
@property (nonatomic, strong, readonly) UIImageView *albumImageView;
@property (nonatomic, strong, readonly) DIMCircularProgressView *progressView;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
- (void)setAlbumImage:(UIImage *)image;
@end

// ==================== 音乐观察者 ====================
@interface DIMMusicObserver : NSObject
@property (nonatomic, assign, readonly) CGFloat currentProgress;
- (void)startObserving;
- (void)stopObserving;
- (CGFloat)getCurrentProgress;
@end

// ==================== Dynamic Island 管理器 ====================
@interface DIMDynamicIslandManager : NSObject
+ (instancetype)sharedInstance;
- (void)setupDynamicIslandView;
- (void)updateProgress:(CGFloat)progress;
- (void)updateAlbumArtwork:(UIImage *)image;
@end

#endif /* Tweak_h */
