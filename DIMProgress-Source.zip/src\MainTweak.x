#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <SpringBoard/SpringBoard.h>
#import <QuartzCore/QuartzCore.h>
#import <libhooker/Libhooker.h>

// 使用 libhooker 的宏
#define LHPrepare(class, sel) lh_prepare_objc_msgSend(class, sel)
#define LHOpen(class, sel, block) lh_hook_msgSend(class, sel, block)
#define LHClose class, sel) lh_unhook_msgSend(class, sel
#define LHExec(block, ...) if(block) ((void(*)(id, SEL, ##__VA_ARGS__))block)(target, _cmd, ##__VA_ARGS__)

#pragma mark - ==================== 配置 ====================

#define ISLAND_WIDTH 120.0
#define ISLAND_HEIGHT 36.0
#define ALBUM_SIZE 26.0
#define ALBUM_CORNER_RADIUS 13.0
#define PROGRESS_LINE_WIDTH 3.5

#pragma mark - ==================== 颜色提取 ====================

@interface DIMColorExtractor : NSObject
+ (UIColor *)extractDominantColorFromImage:(UIImage *)image;
+ (NSArray<UIColor *> *)extractColorsFromImage:(UIImage *)image;
@end

@implementation DIMColorExtractor

+ (UIColor *)extractDominantColorFromImage:(UIImage *)image {
    if (!image) return [UIColor systemPinkColor];
    
    CGSize targetSize = CGSizeMake(50, 50);
    UIGraphicsBeginImageContextWithOptions(targetSize, NO, 1.0);
    [image drawInRect:CGRectMake(0, 0, targetSize.width, targetSize.height)];
    UIImage *smallImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    if (!smallImage) return [UIColor systemPinkColor];
    
    CGImageRef cgImage = smallImage.CGImage;
    if (!cgImage) return [UIColor systemPinkColor];
    
    size_t width = CGImageGetWidth(cgImage);
    size_t height = CGImageGetHeight(cgImage);
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    unsigned char *rawData = malloc(width * height * 4);
    
    CGContextRef context = CGBitmapContextCreate(rawData, width, height, 8, width * 4, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), cgImage);
    
    CGFloat totalR = 0, totalG = 0, totalB = 0;
    int pixelCount = 0;
    
    for (int y = height / 4; y < height * 3 / 4; y++) {
        for (int x = width / 4; x < width * 3 / 4; x++) {
            int byteIndex = (y * width + x) * 4;
            CGFloat r = rawData[byteIndex] / 255.0;
            CGFloat g = rawData[byteIndex + 1] / 255.0;
            CGFloat b = rawData[byteIndex + 2] / 255.0;
            CGFloat brightness = (r + g + b) / 3.0;
            if (brightness > 0.2 && brightness < 0.85) {
                totalR += r;
                totalG += g;
                totalB += b;
                pixelCount++;
            }
        }
    }
    
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    free(rawData);
    
    if (pixelCount > 0) {
        totalR /= pixelCount;
        totalG /= pixelCount;
        totalB /= pixelCount;
        return [UIColor colorWithRed:MIN(totalR * 1.2, 1.0) green:MIN(totalG * 1.2, 1.0) blue:MIN(totalB * 1.2, 1.0) alpha:1.0];
    }
    return [UIColor systemPinkColor];
}

+ (NSArray<UIColor *> *)extractColorsFromImage:(UIImage *)image {
    UIColor *primary = [self extractDominantColorFromImage:image];
    CGFloat h, s, b, a;
    [primary getHue:&h saturation:&s brightness:&b alpha:&a];
    UIColor *endColor = [UIColor colorWithHue:h saturation:s brightness:b * 0.6 alpha:a];
    return @[primary, endColor];
}

@end

#pragma mark - ==================== 圆形专辑封面进度条视图 ====================

@interface DIMCircularAlbumProgressView : UIView
@property (nonatomic, strong) UIImageView *albumImageView;
@property (nonatomic, strong) CAShapeLayer *progressLayer;
@property (nonatomic, assign) CGFloat progress;
@property (nonatomic, strong) UIColor *progressColor;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
- (void)setAlbumImage:(UIImage *)image;
@end

@implementation DIMCircularAlbumProgressView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (void)setupViews {
    self.backgroundColor = [UIColor clearColor];
    _progress = 0.0;
    _progressColor = [UIColor systemPinkColor];
    
    _albumImageView = [[UIImageView alloc] initWithFrame:CGRectMake(
        (self.bounds.size.width - ALBUM_SIZE) / 2,
        (self.bounds.size.height - ALBUM_SIZE) / 2,
        ALBUM_SIZE, ALBUM_SIZE)];
    _albumImageView.contentMode = UIViewContentModeScaleAspectFill;
    _albumImageView.clipsToBounds = YES;
    _albumImageView.layer.cornerRadius = ALBUM_CORNER_RADIUS;
    _albumImageView.backgroundColor = [UIColor systemGray4Color];
    [self addSubview:_albumImageView];
    
    _progressLayer = [CAShapeLayer layer];
    _progressLayer.frame = self.bounds;
    _progressLayer.fillColor = [UIColor clearColor].CGColor;
    _progressLayer.strokeColor = _progressColor.CGColor;
    _progressLayer.lineWidth = PROGRESS_LINE_WIDTH;
    _progressLayer.lineCap = kCALineCapRound;
    _progressLayer.strokeStart = 0;
    _progressLayer.strokeEnd = 0;
    [self.layer addSublayer:_progressLayer];
    
    [self updateProgressPath];
}

- (void)updateProgressPath {
    CGPoint center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
    CGFloat radius = ALBUM_SIZE / 2 + PROGRESS_LINE_WIDTH / 2;
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius
                                                   startAngle:-M_PI_2 endAngle:M_PI_2 * 3 clockwise:YES];
    _progressLayer.path = path.CGPath;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self updateProgressPath];
    _albumImageView.frame = CGRectMake((self.bounds.size.width - ALBUM_SIZE) / 2,
                                       (self.bounds.size.height - ALBUM_SIZE) / 2, ALBUM_SIZE, ALBUM_SIZE);
    _albumImageView.layer.cornerRadius = ALBUM_CORNER_RADIUS;
}

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated {
    _progress = MIN(MAX(progress, 0.0), 1.0);
    if (animated) {
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        animation.fromValue = @(_progressLayer.strokeEnd);
        animation.toValue = @(_progress);
        animation.duration = 0.15;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        animation.fillMode = kCAFillModeForwards;
        animation.removedOnCompletion = NO;
        [_progressLayer addAnimation:animation forKey:@"progressAnimation"];
    }
    _progressLayer.strokeEnd = _progress;
}

- (void)setAlbumImage:(UIImage *)image {
    _albumImageView.image = image;
    [self updateProgressColorFromImage:image];
}

- (void)updateProgressColorFromImage:(UIImage *)image {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSArray *colors = [DIMColorExtractor extractColorsFromImage:image];
        UIColor *primaryColor = colors.firstObject;
        if (primaryColor) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.progressColor = primaryColor;
                self.progressLayer.strokeColor = primaryColor.CGColor;
            });
        }
    });
}

@end

#pragma mark - ==================== 音乐信息提供者 ====================

@interface DIMMusicInfoProvider : NSObject
@property (nonatomic, assign, readonly) CGFloat currentProgress;
@property (nonatomic, strong, readonly) NSDictionary *currentSongInfo;
@property (nonatomic, strong, readonly) UIImage *currentAlbumImage;
+ (instancetype)sharedInstance;
- (void)startMonitoring;
- (void)stopMonitoring;
@end

@implementation DIMMusicInfoProvider {
    NSTimer *_refreshTimer;
    NSTimeInterval _currentTime;
    NSTimeInterval _totalDuration;
    NSDictionary *_currentSongInfo;
    UIImage *_currentAlbumImage;
}

+ (instancetype)sharedInstance {
    static DIMMusicInfoProvider *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [[DIMMusicInfoProvider alloc] init]; });
    return instance;
}

- (void)startMonitoring {
    [self stopMonitoring];
    [self refreshInfo];
    _refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 repeats:YES block:^(NSTimer *timer) {
        [self refreshInfo];
    }];
}

- (void)stopMonitoring {
    [_refreshTimer invalidate];
    _refreshTimer = nil;
}

- (void)refreshInfo {
    MPNowPlayingInfoCenter *infoCenter = [MPNowPlayingInfoCenter defaultCenter];
    NSDictionary *info = infoCenter.nowPlayingInfo;
    if (info && info.count > 0) {
        NSString *title = info[MPMediaItemPropertyTitle];
        NSString *artist = info[MPMediaItemPropertyArtist];
        NSNumber *duration = info[MPMediaItemPropertyPlaybackDuration];
        NSNumber *currentTime = info[MPNowPlayingInfoPropertyElapsedPlaybackTime];
        
        MPMediaItemArtwork *artwork = info[MPMediaItemPropertyArtwork];
        UIImage *albumImage = nil;
        if (artwork && [artwork respondsToSelector:@selector(image)]) {
            albumImage = [artwork imageWithSize:CGSizeMake(ALBUM_SIZE * 4, ALBUM_SIZE * 4)];
        }
        
        _currentSongInfo = @{@"title": title ?: @"未知歌曲", @"artist": artist ?: @"未知艺术家"};
        if (duration) _totalDuration = [duration doubleValue];
        if (currentTime) _currentTime = [currentTime doubleValue];
        if (_totalDuration > 0) {
            [[NSUserDefaults standardUserDefaults] setDouble:_currentTime / _totalDuration forKey:@"DIMProgress"];
        }
        _currentAlbumImage = albumImage;
        
        NSLog(@"[DIMProgress] Playing: %@ - %@", title, artist);
    }
}

- (CGFloat)currentProgress {
    return [[NSUserDefaults standardUserDefaults] doubleForKey:@"DIMProgress"];
}

@synthesize currentSongInfo = _currentSongInfo;
@synthesize currentAlbumImage = _currentAlbumImage;

@end

#pragma mark - ==================== 灵动岛管理器 ====================

@interface DIMIslandManager : NSObject
@property (nonatomic, strong) DIMCircularAlbumProgressView *albumProgressView;
@property (nonatomic, strong) DIMMusicInfoProvider *infoProvider;
@property (nonatomic, assign) BOOL isSetup;
+ (instancetype)sharedInstance;
- (void)setupOnDynamicIsland;
- (void)updateUI;
@end

@implementation DIMIslandManager

+ (instancetype)sharedInstance {
    static DIMIslandManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [[DIMIslandManager alloc] init]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isSetup = NO;
        _infoProvider = [DIMMusicInfoProvider sharedInstance];
    }
    return self;
}

- (void)setupOnDynamicIsland {
    if (_isSetup) return;
    
    UIWindow *diWindow = [self findDynamicIslandWindow];
    if (!diWindow) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[DIMIslandManager sharedInstance] setupOnDynamicIsland];
        });
        return;
    }
    
    CGFloat viewSize = ISLAND_HEIGHT;
    _albumProgressView = [[DIMCircularAlbumProgressView alloc] initWithFrame:CGRectMake(0, 0, viewSize, viewSize)];
    [diWindow addSubview:_albumProgressView];
    _albumProgressView.center = CGPointMake(diWindow.center.x, diWindow.center.y);
    
    _isSetup = YES;
    [_infoProvider startMonitoring];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer *timer) {
        [[DIMIslandManager sharedInstance] updateUI];
    }];
    
    NSLog(@"[DIMProgress] Dopamine tweak loaded!");
}

- (UIWindow *)findDynamicIslandWindow {
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        NSString *className = NSStringFromClass([window class]);
        if ([className containsString:@"DynamicIsland"] || [className containsString:@"Island"]) {
            return window;
        }
    }
    return nil;
}

- (void)updateUI {
    if (!_albumProgressView) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self->_albumProgressView setProgress:[self->_infoProvider currentProgress] animated:YES];
        UIImage *albumImage = [self->_infoProvider currentAlbumImage];
        if (albumImage) {
            [self->_albumProgressView setAlbumImage:albumImage];
        }
    });
}

@end

#pragma mark - ==================== Hook SpringBoard (Libhooker) ====================

// 使用 libhooker hook
__attribute__((constructor))
static void init_hook() {
    // Hook SpringBoard applicationDidFinishLaunching
    Class springboardClass = objc_getClass("SpringBoard");
    SEL sel = @selector(applicationDidFinishLaunching:);
    Method method = class_getInstanceMethod(springboardClass, sel);
    
    if (method) {
        IMP original = method_getImplementation(method);
        IMP hooked = imp_implementationWithBlock(^(id self, id application) {
            ((void(*)(id, SEL, id))original)(self, sel, application);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[DIMIslandManager sharedInstance] setupOnDynamicIsland];
            });
        });
        method_setImplementation(method, hooked);
    }
    
    NSLog(@"[DIMProgress] ========================================");
    NSLog(@"[DIMProgress] Dopamine Dynamic Island Progress Loaded!");
    NSLog(@"[DIMProgress] Supports: QQMusic, Apple Music, Spotify, etc.");
    NSLog(@"[DIMProgress] ========================================");
}
