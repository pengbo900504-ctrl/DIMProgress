$ErrorActionPreference = "SilentlyContinue"

$PackageName = "com.dim.progress"
$Version = "1.0.0"

$ProjectDir = "C:\Users\Administrator\.qclaw\workspace\dynamic-island-music-progress"
$TempDir = "$ProjectDir\_deb_temp"
$OutputFile = "$ProjectDir\$PackageName`_$Version`_iphoneos-arm.deb"
$DesktopFile = "$env:USERPROFILE\Desktop\$PackageName`_$Version`_iphoneos-arm.deb"

Write-Host "Starting deb packaging..." -ForegroundColor Cyan

if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force }
if (Test-Path $OutputFile) { Remove-Item $OutputFile -Force }

$ControlDir = "$TempDir\control"
$DataDir = "$TempDir\data\Library\MobileSubstrate\DynamicLibraries"

New-Item -ItemType Directory -Path $ControlDir -Force | Out-Null
New-Item -ItemType Directory -Path $DataDir -Force | Out-Null

Write-Host "Copying files..." -ForegroundColor Yellow

Copy-Item "$ProjectDir\DynamicIslandMusicProgress.plist" "$DataDir\" -Force
Copy-Item "$ProjectDir\Makefile" "$DataDir\" -Force
Copy-Item "$ProjectDir\README.md" "$DataDir\" -Force

$SrcDir = "$ProjectDir\src"
$DestSrcDir = "$DataDir\src"
if (Test-Path $SrcDir) {
    New-Item -ItemType Directory -Path $DestSrcDir -Force | Out-Null
    Copy-Item "$SrcDir\*" $DestSrcDir -Recurse -Force
}

$ControlContent = "Package: $PackageName`nVersion: $Version`nArchitecture: iphoneos-arm`nMaintainer: DIM Developer`nSection: Tweaks`nDescription: Dynamic Island Music Progress"
$ControlContent | Out-File -FilePath "$ControlDir\control" -Encoding ASCII

$Preinst = "#!/bin/bash`nkillall -9 SpringBoard"
$Preinst | Out-File -FilePath "$ControlDir\preinst" -Encoding ASCII
$Preinst | Out-File -FilePath "$ControlDir\postinst" -Encoding ASCII
$Preinst | Out-File -FilePath "$ControlDir\prerm" -Encoding ASCII
$Preinst | Out-File -FilePath "$ControlDir\postrm" -Encoding ASCII

$DebianBinary = "2.0"
$DebianBinary | Out-File -FilePath "$TempDir\debian-binary" -Encoding ASCII

Write-Host "Creating .deb..." -ForegroundColor Yellow

$DataTarGz = "$TempDir\data.tar.gz"
$ControlTarGz = "$TempDir\control.tar.gz"

Add-Type -AssemblyName System.IO.Compression

function Create-TarGz {
    param($SourceDir, $DestFile)
    
    $TarData = New-Object System.Collections.ArrayList
    
    $Files = Get-ChildItem -Path $SourceDir -Recurse -File
    foreach ($File in $Files) {
        $RelPath = $File.FullName.Replace($SourceDir, ".").Replace("\", "/")
        $Content = [System.IO.File]::ReadAllBytes($File.FullName)
        
        $nameBytes = [System.Text.Encoding]::ASCII.GetBytes($RelPath.PadRight(100).Substring(0, [Math]::Min(100, $RelPath.Length)))
        
        $header = New-Object byte[] 512
        [Array]::Copy($nameBytes, 0, $header, 0, [Math]::Min(100, $nameBytes.Length))
        
        $sizeStr = $Content.Length.ToString()
        $sizeBytes = [System.Text.Encoding]::ASCII.GetBytes($sizeStr.PadLeft(12).Substring(0, 12))
        [Array]::Copy($sizeBytes, 0, $header, 124, 12)
        
        [void]$TarData.AddRange($header)
        
        $padded = New-Object byte[] ((($Content.Length + 511) / 512) * 512)
        [Array]::Copy($Content, 0, $padded, 0, $Content.Length)
        [void]$TarData.AddRange($padded)
    }
    
    [void]$TarData.AddRange((New-Object byte[] 1024))
    
    $TarBytes = $TarData.ToArray()
    $Ms = New-Object System.IO.MemoryStream
    $Gs = New-Object System.IO.Compression.GZipStream($Ms, [System.IO.Compression.CompressionMode]::Compress)
    $Gs.Write($TarBytes, 0, $TarBytes.Length)
    $Gs.Close()
    [System.IO.File]::WriteAllBytes($DestFile, $Ms.ToArray())
}

Create-TarGz "$TempDir\data" $DataTarGz
Create-TarGz $ControlDir $ControlTarGz

$DebMs = New-Object System.IO.MemoryStream
$DebBw = New-Object System.IO.BinaryWriter($DebMs)

$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("!<arch>"))
$DebBw.Write([byte]10)

$BinBytes = [System.IO.File]::ReadAllBytes("$TempDir\debian-binary")
$CtrlBytes = [System.IO.File]::ReadAllBytes($ControlTarGz)
$DataBytes = [System.IO.File]::ReadAllBytes($DataTarGz)

$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("debian-binary         "))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(12)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes($BinBytes.Length.ToString().PadLeft(10)))
$DebBw.Write([byte]96)
$DebBw.Write([byte]10)
$DebBw.Write($BinBytes)
if ($BinBytes.Length % 2 -ne 0) { $DebBw.Write([byte]10) }

$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("control.tar.gz       "))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(12)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes($CtrlBytes.Length.ToString().PadLeft(10)))
$DebBw.Write([byte]96)
$DebBw.Write([byte]10)
$DebBw.Write($CtrlBytes)
if ($CtrlBytes.Length % 2 -ne 0) { $DebBw.Write([byte]10) }

$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("data.tar.gz          "))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(12)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("0".PadLeft(6)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes("100644".PadLeft(8)))
$DebBw.Write([System.Text.Encoding]::ASCII.GetBytes($DataBytes.Length.ToString().PadLeft(10)))
$DebBw.Write([byte]96)
$DebBw.Write([byte]10)
$DebBw.Write($DataBytes)
if ($DataBytes.Length % 2 -ne 0) { $DebBw.Write([byte]10) }

$DebBw.Close()
[System.IO.File]::WriteAllBytes($OutputFile, $DebMs.ToArray())

Copy-Item $OutputFile $DesktopFile -Force
Remove-Item $TempDir -Recurse -Force

$Size = (Get-Item $DesktopFile).Length / 1KB
Write-Host ""
Write-Host "Done!" -ForegroundColor Green
Write-Host "File: $DesktopFile" -ForegroundColor Cyan
Write-Host "Size: $($Size.ToString('F2')) KB" -ForegroundColor Cyan
