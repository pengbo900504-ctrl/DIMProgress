# Dynamic Island Music Progress - 灵动岛音乐进度条

一个苹果 iOS 越狱插件，在灵动岛（Dynamic Island）显示专辑封面和音乐播放进度。

## 📱 功能特点

- ✅ 在灵动岛外圈显示圆形进度条
- ✅ 支持专辑封面显示
- ✅ 渐变粉色配色（可自定义）
- ✅ 流畅的动画效果
- ✅ 支持 iOS 16+ 的 Dynamic Island

## 📂 文件结构

```
dynamic-island-music-progress/
├── Makefile                    # theos 编译配置
├── DynamicIslandMusicProgress.plist  # 插件描述文件
├── src/
│   ├── MainTweak.x            # 主要的 Tweak 代码 (Objective-C)
│   ├── Tweak.h                # 头文件
│   ├── DIMProgressView.swift  # Swift 版本视图
│   ├── ControlCenter.x        # Control Center Hook
│   └── Tweak.x                # 原始实验代码
└── preview.html               # Web 预览效果
```

## 🔧 安装要求

- iOS 16+ 设备（支持 Dynamic Island）
- 已越狱的设备
- 安装了 Theos 工具链
- 安装了 Preferenceloader
- 安装了 MobileSubstrate

## 🚀 编译安装

### 1. 配置 Theos 环境

```bash
# 安装 Theos
sudo apt install git clang llvm
git clone https://github.com/theos/theos.git /opt/theos

# 设置环境变量
export THEOS=/opt/theos
```

### 2. 编译插件

```bash
cd dynamic-island-music-progress
make
make package
```

### 3. 安装到设备

```bash
# 通过 SSH 传输到设备
scp packages/*.deb root@你的设备IP:/tmp/

# 在设备上安装
ssh root@你的设备IP
dpkg -i /tmp/com.yourname.dimprogress_*_iphoneos-arm.deb
```

### 4. 重启 SpringBoard

```bash
killall -9 SpringBoard
```

## ⚙️ 工作原理

### 1. 查找 Dynamic Island 窗口

```objc
for (UIWindow *window in [UIApplication sharedApplication].windows) {
    if ([NSStringFromClass([window class]) containsString:@"DynamicIsland"]) {
        // 找到了 Dynamic Island 窗口
    }
}
```

### 2. 创建专辑封面 + 进度条视图

```objc
// 创建圆形进度条
DIMCircularProgressView *progressView = [[DIMCircularProgressView alloc] init];

// 创建专辑封面容器
DIMAlbumProgressView *albumView = [[DIMAlbumProgressView alloc] initWithSize:60];

// 添加到 Dynamic Island
[dynamicIslandWindow addSubview:albumView];
```

### 3. 监听音乐播放状态

```objc
// 监听 Now Playing 变化
[[NSNotificationCenter defaultCenter] addObserver:self
    selector:@selector(updateProgress:)
    name:MPNowPlayingInfoCenterDidChangeNotification
    object:nil];

// 获取当前进度
MPNowPlayingInfoCenter *infoCenter = [MPNowPlayingInfoCenter defaultCenter];
NSDictionary *info = infoCenter.nowPlayingInfo;
CGFloat progress = [info[MPNowPlayingInfoPropertyElapsedPlaybackTime] doubleValue] /
                   [info[MPMediaItemPropertyPlaybackDuration] doubleValue];
```

### 4. 绘制圆形进度条

```objc
- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGPoint center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
    CGFloat radius = MIN(rect.size.width, rect.size.height) / 2.0 - lineWidth / 2.0;
    
    // 绘制背景轨道
    CGContextAddArc(context, center.x, center.y, radius, 0, M_PI * 2, 0);
    CGContextStrokePath(context);
    
    // 绘制进度
    CGFloat startAngle = -M_PI_2;  // 从顶部开始
    CGFloat endAngle = startAngle + (progress * M_PI * 2);
    CGContextAddArc(context, center.x, center.y, radius, startAngle, endAngle, 0);
    CGContextStrokePath(context);
}
```

## 🎨 自定义配置

在 `src/MainTweak.x` 中修改：

```objc
// 进度条颜色
#define PROGRESS_COLOR [UIColor colorWithRed:1.0 green:0.2 blue:0.4 alpha:1.0]

// 轨道背景色
#define TRACK_COLOR [UIColor colorWithWhite:1.0 alpha:0.2]

// 线宽
#define LINE_WIDTH 4.0

// 动画时长
#define ANIMATION_DURATION 0.3
```

## 📋 依赖

- `libsubstrate.dylib` - Hook 框架
- `UIKit.framework` - iOS UI
- `MediaPlayer.framework` - 音乐播放信息
- `SpringBoard.framework` - SpringBoard Hook

## ⚠️ 注意事项

1. **越狱风险**: 此插件需要越狱，可能导致设备不安全
2. **兼容性**: 仅支持 iOS 16+ 设备
3. **测试**: 请先在模拟器或备用设备上测试
4. **备份**: 安装前请备份重要数据

## 🎯 预览效果

打开 `preview.html` 文件可以在浏览器中预览效果：

```bash
open preview.html
# 或
start preview.html  # Windows
```

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 👨‍💻 作者

Created with ❤️

## 🔗 参考

- [Theos 官方文档](https://theos.dev/)
- [iOS Hook 指南](https://iphonedev.wiki/index.php/Cydia_Substrate)
- [Dynamic Island 开发](https://developer.apple.com/documentation/dynamic-island)
